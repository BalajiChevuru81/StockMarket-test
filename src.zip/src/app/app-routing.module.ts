import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { AdminloginComponent } from './login/adminlogin/adminlogin.component';
import { AdminsignupComponent } from './sign-up/adminsignup/adminsignup.component';
import { UserdetailsComponent } from './login/userdetails/userdetails.component';
import { AdmindetailsComponent } from './login/admindetails/admindetails.component';



const routes: Routes = [
  {path:"LogIn",component:LoginComponent},
  {path:"SignUp",component:SignUpComponent},
  {path:"Admin",component:AdminloginComponent},
  {path:"Signup",component:AdminsignupComponent},
  {path:"userdetails",component:UserdetailsComponent},
  {path:"admindetails",component:AdmindetailsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {} 
