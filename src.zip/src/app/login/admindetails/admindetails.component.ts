import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admindetails',
  templateUrl: './admindetails.component.html',
  styleUrls: ['./admindetails.component.css']
})
export class AdmindetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
