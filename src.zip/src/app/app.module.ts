import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { AdminloginComponent } from './login/adminlogin/adminlogin.component';
import {AdminsignupComponent } from './sign-up/adminsignup/adminsignup.component';
import { UserdetailsComponent } from './login/userdetails/userdetails.component';
import { AdmindetailsComponent } from './login/admindetails/admindetails.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SignUpComponent,
    AdminloginComponent,
    AdminsignupComponent,
    UserdetailsComponent,
    AdmindetailsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
